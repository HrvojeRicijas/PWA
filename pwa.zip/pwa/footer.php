<!DOCTYPE html>
<body>
    <div class="wholeFooter">
        Nachrichten vom <?php echo date('d. m. Y') ?> | Hrvoje Ricijas, 0036510368
    </div>
</body>
</html>